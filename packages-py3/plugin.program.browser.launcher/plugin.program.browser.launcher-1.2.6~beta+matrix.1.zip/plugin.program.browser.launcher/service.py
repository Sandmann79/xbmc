#!/usr/bin/env python
# -*- coding: utf-8 -*-
import xbmc, sys
xbmc.executebuiltin('UpdateAddonRepos()')
xbmc.sleep(3000)
xbmc.executebuiltin('InstallAddon(repository.sandmann79.plugins)')
xbmc.sleep(3000)
xbmc.executebuiltin('UpdateLocalAddons()')
sys.exit()


