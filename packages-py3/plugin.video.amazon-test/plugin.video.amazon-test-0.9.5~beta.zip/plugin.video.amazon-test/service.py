#!/usr/bin/env python
# -*- coding: utf-8 -*-
import xbmc, xbmcgui, json


def jsonRPC(method, props='', param=None):
    """ Wrapper for Kodi's executeJSONRPC API """
    rpc = {'jsonrpc': '2.0',
           'method': method,
           'params': {},
           'id': 1}

    if props:
        rpc['params']['properties'] = props.split(',')
    if param:
        rpc['params'].update(param)
        if 'playerid' in param.keys():
            res_pid = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.GetActivePlayers","id": 1}')
            pid = [i['playerid'] for i in json.loads(res_pid)['result'] if i['type'] == 'video']
            pid = pid[0] if pid else 0
            rpc['params']['playerid'] = pid

    res = json.loads(xbmc.executeJSONRPC(json.dumps(rpc)))
    if 'error' in res.keys():
        return res['error']

    result = res['result']
    return res['result'].get(props, res['result']) if type(result) == dict else result
    

def AddonInfo(addon_id, prop='installed'):
    res = jsonRPC('Addons.GetAddonDetails', prop, {'addonid': addon_id})
    return res['addon'].get(prop, False) if 'addon' in res.keys() else False
    

if __name__ == '__main__':
    if not AddonInfo('repository.sandmann79.plugins'):
        installed = ' and '.join([AddonInfo(a, 'name') for a in ('plugin.video.amazon-test', 'plugin.program.browser.launcher') if AddonInfo(a)])
        xbmc.executebuiltin('UpdateAddonRepos()')
        xbmcgui.Dialog().ok('Repository Update', "Sandmann79s Repository Matrix has been merged with the main repo called Sandmann79s Repository. This repo isn't installed yet. In the next step you can permit the installation, without that %s wouldn't work anymore." % installed)
        xbmc.executebuiltin('InstallAddon(repository.sandmann79.plugins)')
        for s in range(20):
            if AddonInfo('repository.sandmann79.plugins', 'enabled'):
                jsonRPC('Addons.SetAddonEnabled', '', {'addonid': 'repository.sandmann79-py3.plugins', 'enabled': False})
                xbmc.executebuiltin('UpdateAddonRepos()')
                xbmcgui.Dialog().ok('Repository Update', "Repository successfully installed.\nNow you have to install/update %s from Sandmann79s Repository manually. This step is necessary to receive automatic updates, since the source repo has changed. Your app data will remain." % installed)
                break
            xbmc.sleep(1000)
